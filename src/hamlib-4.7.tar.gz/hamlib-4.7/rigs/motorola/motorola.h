#ifndef _MOTOROLA_H
#define _MOTOROLADUMMY_H 1

#include "hamlib/rig.h"

extern struct rig_caps micom_caps;

#endif // _MOTOROLA_H
